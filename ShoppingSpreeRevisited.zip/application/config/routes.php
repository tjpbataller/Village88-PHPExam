<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* products routes */
$route['default_controller'] = 'products';

/* carts routes */
$route['cart'] = 'carts';
$route['add_to_cart'] = 'carts/add_product_to_cart';
$route['delete'] = 'carts/delete_carts_item';

/* default routes in CI */
$route['404_override'] = 'shoppingspreerevisited/';
$route['translate_uri_dashes'] = FALSE;

/* Below are stripe api urls */
$route['checkout'] = "StripePaymentController";
$route['handleStripePayment']['post'] = "StripePaymentController/handlePayment";