<?php
defined('BASEPATH') OR exit('No direct script access allowed');
   
class Carts extends CI_Controller {
    public function index()
    {
        $this->session->set_userdata('user_id', '1');
        $this->load->model("Cart");
        $view_data = array(
            "count" => $this->Cart->count_cart_items(),
            "items" => $this->Cart->get_all(),
            "sum" => $this->Cart->get_cart_total_value()
        );
        $this->load->view('carts/index', $view_data);
    }
    public function add_product_to_cart()
    {
        $product = $this->input->post(NULL, TRUE);
        $this->load->model('Cart');
        if($this->Cart->add_update($product))
        {
            redirect('/');
        }
        else
        {
            $error = array();
            $error['db_error'] = $this->db->error()['message'];
            $this->session->set_flashdata('errors',$errors);
            redirect('/');
        }
    }
    public function delete_carts_item()
    {
        $item_id = $this->input->post('item_id', TRUE);
        $this->load->model('Cart');
        $this->Cart->delete_cart_item($item_id);
        redirect('/cart');
    }
}
?>