<?php
defined('BASEPATH') OR exit('No direct script access allowed');
   
class Products extends CI_Controller {
    public function index()
    {
        $this->load->model('Cart');
        $this->load->model('Product');
        $view_data = array();
        $view_data['products'] = $this->Product->get_all();
        $view_data['cart_item_count'] = $this->Cart->count_cart_items();
        $this->load->view('products/index', $view_data);
    }
}
?>