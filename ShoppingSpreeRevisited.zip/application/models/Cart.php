<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cart extends CI_Model
{
    public function add_update($product)
    {
        // var_dump($product);
        if($this->get($product))
        {
            return $this->update($product);
        }
        else
        {
            return $this->create($product);
        }
    }
    
    public function create($product)
    {   
        $query = "INSERT INTO carts(user_id, product_id, quantity, created_at, updated_at) VALUES(?,?,?,?,?)";
        $values = array(
            'user_id' => $this->session->userdata('user_id'),
            'product_id' => $product['product_id'],
            'quantity' => $product['quantity'],
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        );
        return $this->db->query($query, $values);
    }
    public function get($product)
    {
        $query = "SELECT id FROM carts WHERE user_id = ? AND product_id = ?";
        $data = array(
            "user_id" => $this->session->userdata('user_id'),
            "product_id" => $product["product_id"]
        );
        return $this->db->query($query, $data)->row_array();
    }
    public function get_all()
    {
        $query = "SELECT carts.product_id AS id, products.name, carts.quantity, products.price FROM products INNER JOIN carts ON carts.product_id = products.id WHERE carts.user_id = ?";
        $data = array(
            "user_id" => $this->session->userdata('user_id')
        );
        return $this->db->query($query, $data)->result_array();
    }
    public function update($product)
    {
        $oldValue = $this->get_cart_item_quantity($product);
        $query = "UPDATE carts SET quantity = ?, updated_at = ? WHERE user_id = ? AND product_id = ?";
        $data = array();
        $data["quantity"] = $oldValue + $product["quantity"];
        $data["updated_at"] = date("Y-m-d H:i:s");
        $data["user_id"] = $this->session->userdata('user_id');
        $data["product_id"] = $product["product_id"];
        return $this->db->query($query, $data);
    }
    public function count_cart_items()
    {
        $query = "SELECT COUNT(*) AS count FROM carts WHERE user_id = ?";
        return $this->db->query($query, $this->session->userdata('user_id'))->row_array()['count'];
    }
    public function get_cart_item_quantity($product)
    {
        $query = "SELECT quantity FROM carts WHERE user_id = ? AND product_id = ?";
        $values = array(
            'user_id' => $this->session->userdata('user_id'),
            'product_id' => $product['product_id']
        );
        return $this->db->query($query, $values)->row_array()['quantity'];
    }
    public function delete_cart_item($item_id)
    {
        $query = "DELETE FROM carts WHERE user_id = ? AND product_id = ?";
        $values = array(
            'user_id' => $this->session->userdata('user_id'),
            'product_id' => $item_id
        );
        return $this->db->query($query, $values);
    }
    public function get_cart_total_value()
    {
        $query = "SELECT SUM(quantity*price) AS total_amount FROM carts LEFT JOIN products ON products.id = carts.product_id WHERE user_id = ?";
        $value = array(
            "user_id" => $this->session->userdata('user_id')
        );
        return $this->db->query($query, $value)->row_array()['total_amount'];
    }
}

?>