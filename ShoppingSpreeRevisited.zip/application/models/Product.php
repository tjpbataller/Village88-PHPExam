<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Model
{
    public function get_all()
    {
        $query = "SELECT id, name, price, image FROM products";
        return $this->db->query($query)->result_array();
    }
}

?>