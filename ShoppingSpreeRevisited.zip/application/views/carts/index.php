<?php $this->load->view('partials/header'); ?>
    <div class="row me-auto ms-auto w-50">
        <div class="col-8">
            <h1>Check Out</h1>
        </div>
        <div class="col-4 text-end">
            <h3>Total: $<?= $sum ?></h3>
        </div>
        <div class="col-12">
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Remove Cart Item</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">Do you want to remove "<span id="item_name"></span>"?</div>
                        <form action="delete" method="post" class="modal-footer">
                            <input type="hidden" name="item_id" id="item_id" value="">
                            <input type="button" class="btn btn-secondary" data-bs-dismiss="modal" value="Close">
                            <input type="submit" class="btn btn-danger" value="Yes">
                        </form>
                    </div>
                </div>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
<?php
                    foreach($items as $item){
?>
                    <tr>
                        <td><?= $item['name'] ?></td>
                        <td><?= $item['quantity'] ?></td>
                        <td><?= $item['price'] ?></td>
                        <td>
                            <button type="button" class="btn btn-sm btn-danger delete-btn" data-bs-toggle="modal" data-bs-target="#exampleModal" data-item-id="<?= $item['id']?>" data-item-name="<?= $item['name']?>">X</button>
                        </td>
                    </tr>
<?php
                    }
?>
                </tbody>
            </table>
            <form action="checkout" method="post">
                <input class="btn btn-primary" type="submit" value="Check out">
            </form>
        </div>
    </div>
    <script src="assets/js/delete.js"></script>
<?php $this->load->view('partials/footer'); ?>