<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta name="description" content="This is the activity for Shopping Spree Revisited - CodeIgniter">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/cart.css">
    <title>
<?php
    if(current_url() == base_url())
    {
        echo "Catalog";
        
    }
    else if(current_url() == base_url().'cart')
    {
        echo "Cart";
    }
?>
    </title>
</head>
<body>
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom ms-5 me-5">
        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
            <h1>Shop</h1>
        </a>
        <ul class="nav nav-pills">
            <li class="nav-item">
<?php
                if(current_url() == base_url())
                {
?>
                <a href="cart" class="nav-link fs-4">Cart(<?= $cart_item_count ?>)</a>
<?php
                }
                else if(current_url() == base_url()."cart")
                {
?>  
                <a href="/" class="nav-link fs-4">Catalog</a>
<?php
                }
?>
            </li>
        </ul>
    </header>
