<?php $this->load->view('partials/header'); ?>
    <div class="row row-cols-2 row-cols-md-3 g-2 me-auto ms-auto w-50">
<?php
    if(isset($products))
    {
        foreach($products as $product)
        {
?>
        <div class="col">
            <div class="card h-100">
                <img class="card-img-top h-100" src="<?= $product['image']?>" alt="Card image <?= $product['name'] ?>">
                <div class="card-body">
                    <div class="row">
                        <h4 class="card-text text-start col-6"><?= $product['name'] ?></h4>
                        <h5 class="card-text text-end col-6">$<?= $product['price'] ?></h5>
                    </div>
                    <form class="d-flex w-100" action="add_to_cart" method="post">
                        <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                        <input class="form-control form-control-sm w-25" type="number" min="0" value="0" name="quantity">
                        <input class="btn btn-primary ms-auto" type="submit" value="Buy">
                    </form>
                </div>
            </div>
        </div>
<?php
        }
    }
?>
    </div>
<?php $this->load->view('partials/footer'); ?>