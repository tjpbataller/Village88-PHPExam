$(document).ready(function(){
    $('.delete-btn').on('click',function(){
        let item_id = $(this).attr('data-item-id');
        let item_name = $(this).attr('data-item-name');
        $("#item_name").text(item_name);
        $("#item_id").val(item_id);
    });
});